
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using AutoPOMBuilder.GenericUtilityClasses;

 namespace AutoPOMBuilder.PageObjectMethods
{
   public class LoginPage
   {
   	UIActions _uIActions = new UIActions();

      public By gmailLnk = By.LinkText("Gmail");
      public By imagesLnk = By.LinkText("Images");
      public By gbdLnk = By.XPath("//a[@class='gb_d']");
      public By signinLnk = By.LinkText("Sign in");
      public By aboutLnk = By.LinkText("About");
      public By advertisingLnk = By.LinkText("Advertising");
      public By businessLnk = By.LinkText("Business");
      public By howSearchworksLnk = By.LinkText("How Search works");
      public By privacyLnk = By.LinkText("Privacy");
      public By termsLnk = By.LinkText("Terms");
      public By SearchbyvoiceBtn = By.XPath("//div[@aria-label='Search by voice']");
      public By SearchbyimageBtn = By.XPath("//div[@aria-label='Search by image']");
      public By settingsBtn = By.XPath("//div[contains(text(),'Settings')]");
      public By staysignedoutBtn = By.XPath("//button[contains(text(),'Stay signed out')]");
    }
}
